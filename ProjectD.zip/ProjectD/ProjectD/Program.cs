﻿using MySql.Data.MySqlClient;
using ProjectD.Models;
using System;
using System.Text.RegularExpressions;
using System.Linq;
using System.Collections.Generic;
using System.Collections;
using Microsoft.EntityFrameworkCore.Internal;

namespace ProjectD
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine("Please Choose One Option Below:");
                Console.WriteLine("Option 1: Add Employee Record");
                Console.WriteLine("Option 2: Add Address Record");
                Console.WriteLine("Option 3: Search Employee");
                
                int x = Convert.ToInt32(Console.ReadLine());

                if (x == 1)
                {
                    Console.WriteLine("Fill All the Details");
                    Console.WriteLine("Enter the Employee Name:");
                    string str = Console.ReadLine();
                    Regex r = new Regex(@"^[A-Z a-z]*$");
                    bool m = r.IsMatch(str);
                    if (m == true)
                    {
                        Console.WriteLine("Enter Employee's Age::");
                        int age = Convert.ToInt32(Console.ReadLine());
                        if (age >= 10 && age <= 16)
                        {
                            Console.WriteLine("Enter the Gender:");
                            string str1 = Console.ReadLine();
                            if (str1.ToLower() == "male" || str1.ToLower() == "female")
                            {
                                using (var context = new EmployeedbContext())
                                {
                                    Employee emp = new Employee
                                    {
                                        EmpName = str,
                                        Age = Convert.ToInt32(age),
                                        Gender = str1
                                    };
                                    context.Employee.Add(emp);
                                    context.SaveChanges();
                                }
                            }
                            else
                            {
                                Console.WriteLine("Please Enter your Gender as Male or Female");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Age should be in between 10 to 16");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid Name");
                    }
                }
                else if (x == 2)
                {
                    int empcount = 0;
                    using (var ctx = new EmployeedbContext())
                    {
                        List<Employee> Emp = ctx.Employee.ToList();
                        empcount = Emp.Count;
                        foreach(var items in Emp)
                        {
                            Console.WriteLine(items.EmpId + "." + items.EmpName + "--"+items.Age+"--"+items.Gender);
                        }
                    }
                    Console.WriteLine("Enter the Id of the Employee to which You want to add address:-");
                    int id = Convert.ToInt32(Console.ReadLine());
                    if(empcount>=id)
                    {
                        using (var ct = new EmployeedbContext())
                        {
                            Employee em = new Employee();
                            Console.WriteLine("Fill All The Address Details:-");
                            Console.WriteLine("Enter Your Address::");
                            string adr = Console.ReadLine();
                            Regex ad = new Regex(@"^[A-Z a-z -: 0-9]{1,50}$");
                            bool b = ad.IsMatch(adr);
                            if (b == true)
                            {
                                Console.WriteLine("Please Enter The Pincode:-");
                                int pnc = Convert.ToInt32(Console.ReadLine());
                                Regex pin = new Regex(@"^[0-9]{6}$");
                                bool p = pin.IsMatch(pnc.ToString());
                                if (p == true)
                                {
                                    Address adrs = new Address
                                    {
                                        Addres = adr,
                                        Pincode = pnc,
                                        Employeeid = id
                                    };
                                    ct.Address.Add(adrs);
                                    ct.SaveChanges();
                                }
                                else
                                {
                                    Console.WriteLine("Invalid Pincode Must be 6 digit");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Enter a Valid Address!!");
                            }
                        }
                    
                    }
                }
                else if (x == 3)
                {
                    Console.WriteLine("Please Enter Employee's Name to search:");
                    string name = Console.ReadLine();
                    var result = name.ToLower();
                    using(var con = new EmployeedbContext())
                    {
                        var ijoin = from s in con.Employee
                                    join st in con.Address
                                    on s.EmpId equals st.Employeeid
                                    select new
                                    {
                                        EmpName = s.EmpName,
                                        Age = s.Age,
                                       Gender = s.Gender,
                                      address = st.Addres,
                                        Pincode = st.Pincode
                                    };

                        var results = ijoin.Where(s => s.EmpName.Contains(result));

                        foreach( var items in results)
                        {
                            Console.WriteLine(items.EmpName+"--"+items.Gender+"--"+ items.Age+"--"+items.address+"--"+items.Pincode);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Please Enter a Valid Option");
                }
            } while (true);
            } 
        }
    }
