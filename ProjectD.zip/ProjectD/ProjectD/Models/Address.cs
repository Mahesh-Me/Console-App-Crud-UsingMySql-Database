﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace ProjectD.Models
{
    [Table("address")]
    public class Address
    {
        [Key]
        public int AdId { get; set; }
        public string Addres { get; set; }
        public int Pincode { get; set; }
        public int Employeeid { get; set; }
    }
}
