﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using System.Linq;

#nullable disable

namespace ProjectD.Models
{
    public partial class EmployeedbContext : DbContext
    {
        public  DbSet<Address> Address { get; set; }
        public  DbSet<Employee> Employee { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
             optionsBuilder.UseMySQL("server=127.0.0.1; port=3306; database=Employeedb; uid=root; pwd=6934;");
           // optionsBuilder.UseMySQL("Server = 127.0.0.1; Database = employeedb; uid = root; pwd = 6934; SslMode = None; port = 3306; persistsecurityinfo = True; Convert Zero Datetime = True; Connect Timeout = 36000; Max Pool Size = 1500; Pooling = True");


        }
    }
}
